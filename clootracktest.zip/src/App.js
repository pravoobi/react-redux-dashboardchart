import React from 'react';
import Clootrack from './features/clootrack/chartDashboard';
import './App.css';

function App() {
  return (
    <div className="App">
      <Clootrack />
    </div>
  );
}

export default App;
